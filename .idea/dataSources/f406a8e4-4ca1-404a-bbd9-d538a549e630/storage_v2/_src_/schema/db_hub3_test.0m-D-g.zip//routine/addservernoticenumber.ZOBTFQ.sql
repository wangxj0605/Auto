create procedure addServerNoticeNumber()
  BEGIN

	DECLARE one_adress,all_adress VARCHAR(20) DEFAULT '';
	declare  done INT DEFAULT 0;
	DECLARE
		curl CURSOR FOR SELECT
		table_name 
	FROM
		information_schema.`TABLES` 
	WHERE
		table_name LIKE '%t_brand_sales_head%';
	DECLARE
		CONTINUE HANDLER FOR NOT FOUND 
		SET done = 1;
	OPEN curl;
	REPEAT
		FETCH curl INTO one_adress;
	IF NOT done THEN
		SET @SQL = CONCAT('alter table ', one_adress, ' add COLUMN service_notification_number VARCHAR(50)' );
	PREPARE stmt 
	FROM
		@SQL;
	EXECUTE stmt;

	END IF;
	UNTIL done 
	END REPEAT;
	SELECT
		all_adress;
	CLOSE curl;

END;

