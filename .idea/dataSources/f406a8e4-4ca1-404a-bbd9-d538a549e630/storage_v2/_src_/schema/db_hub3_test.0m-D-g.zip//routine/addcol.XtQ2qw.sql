create procedure ADDCOL()
  BEGIN
	DECLARE	table_temp_name	VARCHAR ( 500 );
	DECLARE	done INT DEFAULT FALSE;
	DECLARE	eror INT DEFAULT 0;
	DECLARE	rs CURSOR FOR SELECT table_name FROM	information_schema.`TABLES` WHERE	TABLE_NAME LIKE '%t_brand_sales_head%';
	
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET eror = 1;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	
	START TRANSACTION;
	
	OPEN rs;
	read_loop:LOOP
		FETCH rs into table_temp_name;
		IF done THEN
			LEAVE read_loop;
		END IF;
		
	SET	@sql=CONCAT('ALTER TABLE ',table_temp_name,' ADD COLUMN `customer_order_code` VARCHAR(50)');
	PREPARE stmt FROM @sql;
	EXECUTE stmt;
	END LOOP;
	IF eror = 1 THEN
		ROLLBACK;
	ELSE
		COMMIT;
	END IF;
	CLOSE rs;
END;

