create procedure converseSalesReport()
  BEGIN   -- 存储过程的开始
	-- 定义销售头表名
  set @headTableNames = CONCAT('t_brand_sales_head_',DATE_FORMAT(CURDATE(),'%Y%m%d')); 
  -- 定义销售明细表名
	set @detailTableNames = CONCAT('t_brand_sales_detail_',DATE_FORMAT(CURDATE(),'%Y%m%d')); 
  -- 查询语句的sql
  set @sqlStr = CONCAT("SELECT CASE when  3 THEN replace(t.CODE,'E','RE') WHEN 4 THEN replace(t.CODE,'E','EE') ELSE t.CODE END 'POS单号', 
t.CODE 'PACS单号', t.PLATFORM_ORDER_CODE '平台单号', t.TRANSACTION_TIME '交易时间',
de.sku_code 'SKU编码', de.brand_sku_code UPC, de.BAR_CODE '条码', 
CASE t.SALES_TYPE WHEN 1 THEN '销售出库' WHEN 2 THEN '退货入库' WHEN 3 THEN '换货入库' WHEN 4 THEN '换货出库' ELSE 'ERROR' END '销售类型',
de.REQUESTED_QTY '数量', de.PRICE_AF_DISCOUNT '折后行单价', de.TOTAL_AF_DISC '折后行总计'
FROM ", @headTableNames," t INNER JOIN  ",@detailTableNames," de ON de.SALES_HEAD_ID = t.id
WHERE t.SHOP_CODE IN ('TBCONVERSEGF','TBCONVERSE') 
AND t.TRANSACTION_TIME BETWEEN CONCAT(date_format( curdate(),'%Y-%m-%d'),' 00:00:00') and CONCAT(date_format( curdate(),'%Y-%m-%d'),' 23:59:59')");
  -- 拼接查询总记录的SQL语句 

  prepare stmt from @sqlStr; -- 预定义一个语句，并将它赋给 stmt

  execute stmt ; -- 执行语句

  deallocate prepare stmt;-- 要释放一个预定义语句的资源

END;

